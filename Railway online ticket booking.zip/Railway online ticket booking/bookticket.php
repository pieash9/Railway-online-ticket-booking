<?php

$con = mysqli_connect("localhost","root","","railway");
if(!$con){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}
if (isset($_POST['submit']))
{
	$name=$_POST['$name'];
	$source=$_POST['source'];
	$destination=$_POST['destination'];
	$dates=$_POST['dates'];
	$adult=$_POST['adult'];
	$child=$_POST['child'];


$sql = "INSERT INTO bookingtickets (name, source, destination, dates, adult, child,) VALUES ('$name', '$source', '$destination', '$dates', '$adult', '$child');";
	if(mysqli_query($con, $sql))
{  
	$message = "You have been successfully book ticket";
}
else
{  
	$message = "Could not insert record"; 
}
	echo "<script type='text/javascript'>alert('$message');</script>";
}
?>


<html>
<head>
	<title>
	Railway ticket booking!!
	</title>
	<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
	
</head><body>
	<table>
		<tr>
		<td>
	<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
	<td>
		<button><a href="index.php"><img src="Home.png" height="40" width="80"></a></button></td></tr></table>
	<hr width="100%">
	<center><div><h2> Book Ticket</h2></div></center>
	<center><form class="form" action="bookingdata.php" method="Post">
		<label>
		<b>Passenger(s) Name:</b>
		</label>
		<input type="text" name="name" required="required" placeholder="Enter your Name"><br/><br/>
		<label for="From"><b>
		From:</b></label>
		<select name="source">
			<option value="Chattogram">Chattogram</option>
			<option value="Dhaka">Dhaka</option>
			<option value="Noakhali">Noakhali</option>
			<option value="Santahar">Santahar</option>
			<option value="Khulna">Khulna</option>
		    <option value="Rajshahi">Rajshahi</option>
		    <option value="Sirajganj">Sirajganj</option>
			<option value="Benapole">Benapole</option></select><br/><br/>
		<label><b>To:</b></label>
		<select name="destination"><option value="Mymensingh">Mymensingh</option>
			<option value="Kishoreganj">Kishoreganj</option>
			<option value="Mohanganj">Mohanganj</option>
			<option value="Sylhet">Sylhet</option>
			<option value="Jamalpur">Jamalpur</option>
			<option value="Panchagarh">Panchagarh</option></select><br/><br/>
		<label for="date"><b>
		Date:</b>
		</label><input type="date" name="dates" id="dates" required><br/><br/>
		<label for="Adult"><b>No Adult's</b></label><select name="adult" id="child">
			<option>0</option>
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
			<option>7</option>

		</select><br/><br/>
		<label for="child"><b>No Child's</b></label><select name="child" id="child" required>
			<option>0</option>
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
			<option>7</option>

		</select><br/><br/>
		<button type="submit" name="submit"  class="button">BOOKING </button>
		
	</form></center>
</body>
</html>

