

<?php

session_start();
$conn = mysqli_connect("localhost","root","","railway");
if(!$conn){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}

include("bookticket.php");
$name=$_REQUEST['name'];
$source=$_REQUEST['source'];
$destination=$_REQUEST['destination'];
$dates=$_REQUEST['dates'];
$adult=$_REQUEST['adult'];
$child=$_REQUEST['child'];

//inserting data into table

 $query = mysqli_query($db_connect,"INSERT INTO `bookingtickets` (`id`, `name`, `source`, `destination`, `dates`, `adult`, `child`) VALUES ('','$name', '$source', '$destination', '$dates', '$adult', '$child')") or die(mysqli_error($db_connect));
mysqli_close($db_connect);
echo '<script type="text/javascript">'; 
echo 'alert("Booking sucessfully!");'; 
echo 'window.location.href = "dataretrive.php";';
echo '</script>';
?>

